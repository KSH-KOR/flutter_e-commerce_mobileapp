import 'package:flutter/cupertino.dart';

Widget addHorizontalSpace(double width){
  return SizedBox(width: width,);
}
Widget addVerticalSpace(double height){
  return SizedBox(height: height,);
}