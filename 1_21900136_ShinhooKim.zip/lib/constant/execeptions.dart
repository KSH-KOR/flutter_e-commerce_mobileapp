
class GoogleSignInExeception implements Exception{

}
class GenericAuthException implements Exception{

}
class UserNotLoggedInAuthException implements Exception{

}