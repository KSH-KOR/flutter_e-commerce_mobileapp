
const homepageRoute = '/';
const loginRoute = '/login';
const detailRoute = '/detail';
const myPageRoute = '/my-page';
const addNewProductRoute = '/add-new-product';
const profileRoute = '/profile';
const wishListRoute = '/wish-list';