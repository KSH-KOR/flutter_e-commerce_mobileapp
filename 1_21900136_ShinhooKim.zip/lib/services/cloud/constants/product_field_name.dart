const productNameFieldName = 'name';
const productPriceFieldName = 'price';
const productDescriptionFieldName = 'description';
const likedFieldName = 'is_liked';
const creatorIdFieldName = 'creator_id';
const productIdFieldName = 'product_id';
const createdTimeFieldName = 'created_time';
const modifiedTimeFieldName = 'modified_time';
const imagePathFieldName = 'image';

const productCollectionName = 'products';