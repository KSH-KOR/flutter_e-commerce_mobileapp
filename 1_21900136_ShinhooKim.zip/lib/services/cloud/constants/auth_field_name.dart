const userNameFieldName = "name";
const userEmailFieldName = "email";
const statusMessageFieldName = "status-message";
const userIdFieldName = "uid";
const userProfileURLFieldName = "profile-image-url";

const authCollectionName = 'users';

const favoritedProductsCollecetionName = 'favorited-products';
